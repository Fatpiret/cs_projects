package sortedList;

public class EmptyCollectionException extends RuntimeException {

	private static final long serialVersionUID = 3850120511042313442L;
	
	public EmptyCollectionException() {
		super();
	
		
	}
	public EmptyCollectionException(String msg) {
		super(msg);


	}
	}



