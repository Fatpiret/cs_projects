package ds.priorityqueue;

public enum PriorityType {
	MIN, MAX

}
