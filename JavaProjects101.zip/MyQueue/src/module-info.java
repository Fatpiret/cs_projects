/**
 * 
 */
/**
 * @author nijem
 *
 */
module MyQueue {
}