/**
 * 
 */
/**
 * @author nijem
 *
 */
module maze {
}