package listi;

public class EmptyCollectionException extends RuntimeException {
	

	private static final long serialVersionUID = 6655812427340300033L;
	
	public EmptyCollectionException() {
		super();
	
		
	}
	public EmptyCollectionException(String msg) {
		super(msg);
	
	}

}
