package datastructure.tree;

public class EmptyCollectionException extends RuntimeException {

	private static final long serialVersionUID = 6888621124674877096L;
	
	public EmptyCollectionException(String msg) {
		super(msg);    
	}

}
