package myStack;

public class EmptyStackExeption extends RuntimeException {
	
	public EmptyStackExeption(String msg) {
		super(msg);
	}

	private static final long serialVersionUID = 1L;
	

}
