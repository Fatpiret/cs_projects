/**
 * 
 */
/**
 * @author nijem
 *
 */
module MyStack1 {
}