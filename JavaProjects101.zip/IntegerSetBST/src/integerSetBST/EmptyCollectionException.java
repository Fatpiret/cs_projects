package integerSetBST;

public class EmptyCollectionException extends RuntimeException {

	private static final long serialVersionUID = -7343923880220751354L;
	public EmptyCollectionException(String msg) {
		super(msg);    
	}

}
