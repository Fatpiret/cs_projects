package integerSetBST;

public class ElementDoesNotExistException extends RuntimeException {

	private static final long serialVersionUID = 5269887342557356982L;
	
	public ElementDoesNotExistException(String msg) {
		super(msg);
	}
	

}
