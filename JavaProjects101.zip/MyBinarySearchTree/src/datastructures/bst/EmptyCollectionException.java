package datastructures.bst;

public class EmptyCollectionException extends RuntimeException {

	private static final long serialVersionUID = 7343679752136608057L;
	
	public EmptyCollectionException(String msg) {
		super(msg);
	}
	

}
