/**
 * 
 */
/**
 * @author nijem
 *
 */
module maxDigits {
}